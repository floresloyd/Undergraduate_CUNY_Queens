Usage:
1. Have test.txt, and train.txt in local directory as the notebooks
2. run cell by cell or run all


My is written as a notebook so the output is already included. If you want to view my code without opening the notebooks it is also viewable via my github repository.

Link: https://github.com/floresloyd/fall24/blob/main/csci366/hw1/part2.ipynb